using System;
using FreezerGameplay;
using UnityEditor;
using UnityEngine;

public static class PickupDataChecks
{
    [MenuItem("Tools/Freezer Game/Run Pickup Capacity Checks")]
    static void Run()
    {
        var go = new GameObject("Temporary pickup checks");
        var db = ScriptableObject.CreateInstance<GameplayDatabase>();
        try
        {
            var inventory = go.AddComponent<InventoryController>();
            inventory.store = go.AddComponent<GameProgressStore>();
            inventory.database = db;
            inventory.capacity = 3;
            db.items = new[] { new ItemDefinition { id="flour" }, new ItemDefinition { id="hat", rarity=ItemRarity.KeyItem } };
            Check(inventory.TryAdd("flour", 3), "Fill bag");
            Check(!inventory.TryAdd("hat") && inventory.Count("hat")==0, "Reject entire gain");
            Check(inventory.TryExchange(new[] { Amount("flour",2) }, new[] { Amount("hat",1) }), "Exchange final balances");
            Check(!inventory.TryDiscard("hat"), "Key rarity protects from discard");
            inventory.store.Data.inventory.Add(new InventoryEntry { itemId="hat", instanceId="unique", quantity=2 });
            Check(inventory.UnitsHeld==4 && !inventory.FitsPickup(1), "Count unique records and preserve oversized saves");
            Check(inventory.TryDiscard("flour") && inventory.UnitsHeld==3, "Allow reductions while over limit");
            inventory.store.MarkEvent("pickupSeen:flour");
            var saved = JsonUtility.ToJson(inventory.store.Snapshot());
            inventory.store.Restore(JsonUtility.FromJson<GameProgress>(saved));
            Check(inventory.store.HasEvent("pickupSeen:flour"), "Round-trip discovery through existing save format");
            Debug.Log("Pickup capacity and discovery data checks passed.");
        }
        finally { UnityEngine.Object.DestroyImmediate(go); UnityEngine.Object.DestroyImmediate(db); }
    }
    [MenuItem("Tools/Freezer Game/Run Pickup Counter Checks")]
    static void CounterChecks()
    {
        var go = new GameObject("Temporary counter checks");
        go.SetActive(false);
        try
        {
            var store = go.AddComponent<GameProgressStore>();
            var feedback = go.AddComponent<PickupFeedback>();
            feedback.store = store;
            go.SetActive(true);
            // Edit Mode does not guarantee ordinary MonoBehaviour lifecycle callbacks.
            feedback.SendMessage("OnDisable", SendMessageOptions.RequireReceiver);
            feedback.SendMessage("OnEnable", SendMessageOptions.RequireReceiver);
            var flour = new ItemDefinition { id = "flour", displayName = "Flour" };
            for (int count = 1; count <= 12; count++)
            {
                feedback.ShowItem(flour, 1);
                Check(feedback.RecentQuantity == count, "Repeated pickup count " + count);
            }
            feedback.ShowItem(new ItemDefinition { id = "bread", displayName = "Bread" }, 1);
            Check(feedback.RecentQuantity == 1, "Different item starts a new count");
            feedback.ShowFull();
            Check(feedback.RecentQuantity == 0, "Full bag does not add a pickup");
            feedback.ShowItem(flour, 1);
            Check(feedback.RecentQuantity == 1, "Next successful pickup starts at one");
            store.Restore(new GameProgress());
            Check(feedback.RecentQuantity == 0, "Loading resets the transient counter");
            Debug.Log("Pickup counter checks passed. Test timing, colours, and independent solid pickups in Play Mode.");
        }
        finally { UnityEngine.Object.DestroyImmediate(go); }
    }

    static ItemAmount Amount(string id,int n) => new ItemAmount { itemId=id, quantity=n };
    static void Check(bool result,string message) { if (!result) throw new Exception(message); }
}
